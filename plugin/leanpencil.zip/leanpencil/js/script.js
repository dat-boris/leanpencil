$(document).ready(function (e) {
	
	function addCredits() {
		
		var total = 0;
		$("#lp-credit-list").find("input:checkbox").each(function() {
			total += parseInt(this.value, 10);
		});
		$("#num_credits").html(total);
	}
	addCredits();
	
	$("#lp-credit-list input:checkbox").change( function() { 
		addCredits();
	});

    function confirmOrder() {
        var postData = {};

        $("#post").find(':input').each(function()
            {
                postData[$(this).attr('name')] = $(this).val();
            }
        );

        alert(JSON.stringify(postData));
        // TODO: 1. get JSON and call API
        $.getJSON(
            "http://api.leanpencil.com/api/v0/content.json?jsoncallback=?",
            { data : JSON.stringify(postData) },
            callback
        );

    }
	
});
